package com.example.conversor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
