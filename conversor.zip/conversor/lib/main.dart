import 'package:flutter/material.dart';
import 'app/tela_conversor.dart';
void main(){
  runApp(MaterialApp(
    home: Home(),
    theme: ThemeData(

    ),
  ));
}